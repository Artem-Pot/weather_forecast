let keyApi = '75b9c736df53403297a115728241601'; //ключ

export { keyApi };